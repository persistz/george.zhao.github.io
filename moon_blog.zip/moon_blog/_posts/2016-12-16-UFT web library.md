---
layout: post
title:  "A Web Automation Test Library Based on UFT"
date:   2015-12-16
excerpt: "..."
project: true
tag:
- testing
comments: true
---


## A Web Automation Test Library Based on UFT

##### 介绍

15年刚进入hp实习时完成的library，基于UFT的描述性编程实现，基本可以实现大部分web端的操作。

https://github.com/persistz/UFT-QTP_Web-Common-Function