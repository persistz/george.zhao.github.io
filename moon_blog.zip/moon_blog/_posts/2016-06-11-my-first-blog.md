---
layout: post
title: "First Blog and Jecyll configure process"
date: 2016-06-11
excerpt: "Tester or developer?"
tag: [jekyll, blog]
comments: true
---

### 这是我的第一篇个人博客

搭建站点使用了以下工具：

* GithubPages
* Ruby
* Jekyll
* 模板来源于 [Github Moon](https://github.com/TaylanTatli/Moon)

问题记录：

* 使用 Ruby 时，如果报错，查看错误信息，是否缺少组件，使用 gem install 安装
* Ruby 遇到 certificate verify failed 问题，手动复制cacert.pem文件，并配置系统环境变量解决
     
### 希望自己能把博客坚持写下去。    